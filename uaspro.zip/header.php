<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>websyte sekolah SMA N.1 HILISALAWAÁHE</title>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<style>
		.heading{
			text-align: center;
			top margin: 40px;
		}
		.heading h1{
			font-size: 50px;
			color: rgb(146, 54, 54);
			margin-bottom: 10px;
		}
		.heading{
			font-size: 15px;
			color: rgb(41,45,45);
			margin-bottom: 50px;
		}
		.about{
			display: flex;
			align-items: center;
			width: 85%;
			margin: auto
		}
		.about img{
			flex: 0 70%;
			max-width: 70%;
			height: auto;
		}
		.content {
			padding: 35px;
         }
		.content h2{
			color: rgb(41,45,45);
			font-size: 24px
			margin: 15px 0px;
		}
		.content p{
			color: #b2babb;
			font-size: 18px;
			line-height: 1,5;
			margin: 15px 0px;
		}

	
  .navbar {
    background-color: blue;
  }

  .navbar a {
    color: white;
  }

	</style>
	</head>
	<body>
		<!--navbar start-->
		<nav class="navbar navbar-expand-sm justify-content-center">
			<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed"
				 data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				<span class="sr-only">Toggle Nav</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">SMA N.1 HILISALAWA'AHE</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
				<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home">HOME <span class="sr-only">(current)</span></a></li>
				<li><a href="about.php"><span class="glyphicon glyphicon-info-sign">ABOUT</a></li>
				<li><a href="pendaftaran.php"><span class="glyphicon glyphicon-user">PENDAFTARAN SISWA BARU</a></li>
				<li><a href="siswa.php"><span class="glyphicon glyphicon-user">DATA SISWA</a></li>
				<li><a href="galeri.php">GALERI</a></li>
				<li><a href="login.php">LOGIN</a></li>
				</ul>
			</div>
			</div>
	</nav>