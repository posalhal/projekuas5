<?php include "header.php"; ?>

<!--awal pendaftaran-->
	<div id="pendaftaran.php">
		<div class="pendaftaran">
			<h2 class="text-center">PENDAFTARAN</h2>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php 

					if(@$_GET['pesan']=="inputBerhasil"){

					?>
									<div class="alert alert-success">
									Terima kasih,  anda telah berhasil mendaftar! 
									</div>
					<?php

					}

					?>
			<form action="proses-pendaftaran.php" method="post">
				<div class="form-group">
				<label for="nik">NIK</label>
				<input type="number" class="form-control" name="nik" placeholder="Isikan NIK">
				</div>
				<div class="form-group">
				<label for="nama">Nama</label>
				<input type="text" class="form-control" name="nama" placeholder="Isikan Nama Lengkap">
				</div>
				<label for="tanggal_lahir">Tanggal Lahir</label>
				<input type="date" class="form-control" name="tanggal_lahir" placeholder="Isikan tanggal_lahir Lengkap">
				</div>
				<div class="form-group">
				<label for="jenis_kelamin">Jenis Kelamin</label>
				<select name="jenis_kelamin" class="form-control">
					<option value="Laki-laki">Laki-laki</option>
					<option value="Perempuan">Perempuan</option>
				 </select>
				</div>
				<div class="form-group">
				<label for="asal_sekolah">Asal Sekolah</label>
				<input type="text" class="form-control" name="asal_sekolah" placeholder="Isikan asal sekolah Lengkap">
				</div>


				<div class="form-group">
				<label for="nama_orangtua">Nama Orangtua</label>
				<input type="text" class="form-control" name="nama_orangtua" placeholder="Isikan nama_orangtua/wali Lengkap">
				</div>

				<div class="form-group">
				<label for="telepon">Nomor telepon</label>
				<input type="text" class="form-control" name="telepon" placeholder="Isikan Nomor telepon Lengkap">
				</div>



				<div class="form-group">
				<label for="alamat">Alamat</label>
				<textarea name="alamat"class="form-control" placeholder="Isikan Alamat Lengkap"></textarea>
				</div>

				<div class="form-group">
				<label for="email">Email</label>
				<input type="text" class="form-control" name="email" placeholder="Isikan email Lengkap">
				</div>

				<div class="form-group">
				<label for="jurusan">Jurusan</label>
				<select name="jenis_kelamin" class="form-control">
					<option value="Ilmu Pengetahuan Alam">Ilmu Pengetahuan Alam</option>
					<option value="Ilmu Pengetahuan Sosial">Ilmu Pengetahuan Sosial</option>
				 </select>
				</div>
				<button type="submit" class="btn btn-info">Simpan</button>
				<button type="reset" class="btn btn-info">Batal</button>
			</form>
			</div>
		</div>
	</div>
	<!--akhir pendaftaran-->

	<?php include "footer.php";?>