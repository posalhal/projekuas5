
<?php include "header.php"; ?>


<style>
.heading{
			font-size: 20px;
			color: rgb(41, 45, 45);
			margin-bottom: 50px;
		}
		.ABOUT{
			display: flex;
			align-items: center;
			width: 85%;
			margin: auto
		}
		.ABOUT img{
			flex: 0 50%;
			max-width: 50%;
			height: auto;
		}
</style>
<!--awal about-->
		<div class="heading">
			<br><br><br>
	 		<h2>TENTANG SMA N.1 HILISALAWA'AHE</h2>
       <div id="ABOUT">
		<div class="ABOUT">
		<img src="gambarp1.jpg">
		<div class="content">
		<p><h5>SMA  N.1 HILISALAWA'AHE adalah salah satu pendidikan dengan jenjang SMA Di sisobahili siwalawa,Kec.Hilisalawa'ahe Kab.Nias selatan sumatra utara.SMA N.1 HILISALAWA'AHE berdiri pada tahun 2012.Dalam menjalankan kegiatannya SMA N.1 HILISALAWA'AHE berada dibawah naungan kementrian pendidikan dan kebudayaan.SMA N.1 HILISALAWA'AHE sudah terakreditas B,berdasarkan sertifikat 694/BAP-SM/LL/XI/2017.Fasilitas yang disediakan SMA N.1 Hilisalawa'ahe menyediakan listrik untuk membantu kegiatan belajar mengajar, ayo segera daftarkan diri anda di SMA N.1 Hilisalawa'ahe bersekolah di SMA N.1 Hilisalawa'ahe kamu akan mendapatkan fasilitas yang lengkap, dan lingkungan sekolah yang kondusif, ramah, dan berbudi pekerti luhur, untuk alur pendaftaran bisa anda lihat melalu halaman website proposal,   </h5>
		</p>
		</div>
	</div>
	    <br><br><br>
	<!--akhir about-->

	<?php include "footer.php";?>