<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id=$_POST['pendaftaran_id'];
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tanggal_lahir=$_POST['tanggal_lahir'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$asal_sekolah=$_POST['asal_sekolah'];
$nama_orangtua=$_POST['nama_orangtua'];
$telepon=$_POST['telepon'];
$alamat=$_POST['alamat'];
$email=$_POST['email'];
$jurusan=$_POST['jurusan'];

$ubah=$koneksi->query("update pendaftaran set nik='$nik', nama='$nama', tanggal_lahir='$tanggal_lahir', jenis_kelamin='$jenis_kelamin', asal_sekolah='$asal_sekolah', nama_orangtua='$nama_orangtua', telepon='$telepon', alamat='$alamat', email='$email', jurusan='$jurusan' where pendaftaran_id='$id'");

if($ubah==true){

    header("location:tampil-pendaftaran.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>