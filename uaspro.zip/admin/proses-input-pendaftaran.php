<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tanggal_lahir=$_POST['tanggal_lahir'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$asal_sekolah=$_POST['asal_sekolah'];
$nama_orangtua=$_POST['nama_orangtua'];
$telepon=$_POST['telepon'];
$alamat=$_POST['alamat'];
$email=$_POST['email'];
$jurusan=$_POST['jurusan'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into pendaftaran(nik,nama,tanggal_lahir,jenis_kelamin,asal_sekolah,nama_orangtua,telepon,alamat,email,jurusan) 
                        values ('$nik', '$nama', '$tanggal_lahir', '$jenis_kelamin', '$asal_sekolah', '$nama_orangtua', '$telepon', '$alamat', '$email', '$jurusan')");

if($simpan==true){

    header("location:tampil-pendaftaran.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>