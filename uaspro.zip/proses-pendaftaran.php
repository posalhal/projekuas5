
<?php

include "koneksi.php";
$nik = $koneksi->real_escape_string($_POST['nik']); 
$nama = $koneksi->real_escape_string($_POST['nama']); 
$tanggal_lahir = $koneksi->real_escape_string($_POST['tanggal_lahir']); 
$jenis_kelamin = $koneksi->real_escape_string($_POST['jenis_kelamin']); 
$asal_sekolah = $koneksi->real_escape_string($_POST['asal_sekolah']); 
$nama_orangtua = $koneksi->real_escape_string($_POST['nama_orangtua']);
$telepon = $koneksi->real_escape_string($_POST['telepon']); 
$alamat = $koneksi->real_escape_string($_POST['alamat']); 
$email = $koneksi->real_escape_string($_POST['email']);
$jurusan = $koneksi->real_escape_string($_POST['jurusan']); 


$simpan=$koneksi->query("insert into pendaftaran(nik,nama,tanggal_lahir,jenis_kelamin,asal_sekolah,nama_orangtua,telepon,alamat,email,jurusan) 
                        values ('$nik', '$nama', '$tanggal_lahir','$jenis_kelamin','$asal_sekolah','$nama_orangtua','$telepon','$alamat','$email','$jurusan')");

if($simpan==true){

    header("location:pendaftaran.php?pesan=inputBerhasil");
} else{
    echo "Error";
}

?>