<?php include "header.php"; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri Foto</title>
    <style>
        .gallery {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }

        .gallery img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            background-color: #;
        }
    </style>
</head>
</head>
<body>

    <h2>Galeri Foto</h2>

    <div class="gallery">
        <img src="gambar12.jpg" alt="Foto 1">
        <img src="gambarp1.jpg" alt="Foto 2">
        <img src="gambarp2.jpg" alt="Foto 3">
        <img src="pramuka.jpg" alt="Foto 4">
        <img src="gambar15.jpg" alt="Foto 5">
        <img src="pramuka1.jpg" alt="Foto 6">
    </div>

</body>
</html>

   <?php include "footer.php";?>